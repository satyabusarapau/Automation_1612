// Array of restricted Linux commands
const restrictedCommands = [
  'rm', 'rmdir', 'unlink', 'mv', 'chmod', 'chown', 'chgrp', 
  'truncate', 'ln', 'sed', 'awk', 'cp', 'edit', 'delete'
];

// Function to validate if the command contains restricted commands
function validateCommand(command) {
  return restrictedCommands.some(restrictedCmd => command.includes(restrictedCmd));
}

// Fetch all servers on page load
async function fetchServers() {
  const response = await fetch('/api/servers');
  const servers = await response.json();
  populateServerDropdown(servers);
}

// Populate server dropdown
function populateServerDropdown(servers) {
  const serverDropdown = document.getElementById('serverDropdown');
  serverDropdown.innerHTML = '<option value="">-- Select Server --</option>';
  for (const serverName in servers) {
    const option = document.createElement('option');
    option.value = serverName;
    option.textContent = serverName;
    serverDropdown.appendChild(option);
  }
}

// Update command dropdowns based on selected server
async function updateCommands() {
  const serverDropdown = document.getElementById('serverDropdown');
  const selectedServer = serverDropdown.value;

  if (!selectedServer) return;

  const response = await fetch('/api/servers');
  const servers = await response.json();

  const commandSelect1 = document.getElementById('commandSelect1');
  const commandSelect2 = document.getElementById('commandSelect2');

  // Populate commands for Command 1 and Command 2 dropdowns
  commandSelect1.innerHTML = '<option value="">-- Select Command 1 --</option>';
  commandSelect2.innerHTML = '<option value="">-- Select Command 2 --</option>';
  servers[selectedServer]?.command1.forEach(cmd =>
    commandSelect1.appendChild(new Option(cmd, cmd))
  );
  servers[selectedServer]?.command2.forEach(cmd =>
    commandSelect2.appendChild(new Option(cmd, cmd))
  );
}

// Add a new server and commands
async function addServer() {
  const newServer = document.getElementById('newServer').value.trim();
  const newCommand1 = document.getElementById('newCommand1').value.trim();
  const newCommand2 = document.getElementById('newCommand2').value.trim();

  // Validate command inputs
  if (validateCommand(newCommand1) || validateCommand(newCommand2)) {
    alert("The command contains restricted Linux commands and cannot be used.");
    return;
  }

  if (!newServer || !newCommand1 || !newCommand2) {
    alert('Please fill in all fields');
    return;
  }

  const response = await fetch('/api/servers', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      serverName: newServer,
      commands: {
        command1: [newCommand1],
        command2: [newCommand2],
      },
    }),
  });

  const result = await response.json();
  alert(result.message);

  // Refresh server list
  fetchServers();
}

// Add additional commands for the selected server
async function addAdditionalCommands() {
  const serverDropdown = document.getElementById('serverDropdown');
  const selectedServer = serverDropdown.value;
  const newCommand1 = document.getElementById('newCommand1').value.trim();
  const newCommand2 = document.getElementById('newCommand2').value.trim();

  // Validate command inputs
  if (validateCommand(newCommand1) || validateCommand(newCommand2)) {
    alert("The command contains restricted Linux commands and cannot be used.");
    return;
  }

  if (!selectedServer || (!newCommand1 && !newCommand2)) {
    alert('Please fill in all fields');
    return;
  }

  const response = await fetch('/api/servers', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      serverName: selectedServer,
      commands: {
        command1: newCommand1 ? [newCommand1] : [],
        command2: newCommand2 ? [newCommand2] : [],
      },
    }),
  });

  const result = await response.json();
  alert(result.message);

  // Refresh server list and commands
  updateCommands();
}

// Execute selected command and show logs
async function executeCommand(commandSelectId, logId) {
  const commandSelect = document.getElementById(commandSelectId);
  const command = commandSelect.value;

  if (!command) {
    alert('Please select a command');
    return;
  }

  const response = await fetch('/api/execute', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ command }),
  });

  const result = await response.json();
  document.getElementById(logId).value = result.output;
}

// Initialize the app
fetchServers();
