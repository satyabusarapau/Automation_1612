const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const { exec } = require('child_process');
const path = require('path');

// Initialize the app
const app = express();
const port = 3000;

// Middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());

// File to store the servers data
const serversFile = 'servers.json';

// Helper function to read servers data from the file
const readServersFile = () => {
  if (!fs.existsSync(serversFile)) {
    fs.writeFileSync(serversFile, JSON.stringify({}));
  }
  return JSON.parse(fs.readFileSync(serversFile, 'utf-8'));
};

  

// Helper function to write to the servers file
const writeServersFile = (data) => {
  fs.writeFileSync(serversFile, JSON.stringify(data, null, 2));
};

// Fetch all servers and their commands
app.get('/api/servers', (req, res) => {
  const servers = readServersFile();
  res.json(servers);
});

// Add a new server and commands
app.post('/api/servers', (req, res) => {
  const { serverName, commands } = req.body;
  const servers = readServersFile();

  if (servers[serverName]) {
    // If the server already exists, append only unique commands
    servers[serverName].command1 = [
      ...new Set([...servers[serverName].command1, ...commands.command1]),
    ];
    servers[serverName].command2 = [
      ...new Set([...servers[serverName].command2, ...commands.command2]),
    ];
  } else {
    // If the server doesn't exist, create it
    servers[serverName] = {
      command1: [...new Set(commands.command1)],
      command2: [...new Set(commands.command2)],
    };
  }

  writeServersFile(servers);
  res.json({ message: 'Server and commands added/updated successfully' });
});

// Execute a command on the server
app.post('/api/execute', (req, res) => {
  const { command } = req.body;

  // Execute the command
  exec(command, (error, stdout, stderr) => {
    if (error) {
      return res.json({ output: `Error executing command: ${error.message}` });
    }
    if (stderr) {
      return res.json({ output: `stderr: ${stderr}` });
    }
    res.json({ output: stdout });
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
